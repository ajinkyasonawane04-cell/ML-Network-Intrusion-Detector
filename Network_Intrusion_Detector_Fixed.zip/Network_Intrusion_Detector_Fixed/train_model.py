"""
ML Network Intrusion Detector - training script.
Run from this folder:
    python train_model.py
Or choose a CSV and target column:
    python train_model.py --data dataset/your_file.csv --target label
"""
from pathlib import Path
import argparse
import joblib
import pandas as pd

from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

ROOT = Path(__file__).resolve().parent
DEFAULT_DATA = ROOT / "dataset" / "sample_network_traffic.csv"
MODEL_DIR = ROOT / "model"
MODEL_PATH = MODEL_DIR / "intrusion_model.pkl"

def find_dataset(explicit_path=None):
    if explicit_path:
        path = Path(explicit_path)
        if not path.is_absolute():
            path = ROOT / path
        if not path.exists():
            raise FileNotFoundError(f"Dataset file not found: {path}")
        return path

    if DEFAULT_DATA.exists():
        return DEFAULT_DATA

    candidates = sorted((ROOT / "dataset").glob("*.csv"))
    if candidates:
        return candidates[0]

    raise FileNotFoundError(
        "\nNo CSV dataset found.\n"
        f"Expected: {DEFAULT_DATA}\n"
        "Fix: create the dataset folder and add sample_network_traffic.csv, "
        "or run: python generate_sample_data.py"
    )

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default=None, help="CSV dataset path")
    parser.add_argument("--target", default="label", help="Target/label column name")
    args = parser.parse_args()

    csv_path = find_dataset(args.data)
    print(f"Loading dataset: {csv_path}")
    df = pd.read_csv(csv_path)
    if args.target not in df.columns:
        raise ValueError(
            f"Target column '{args.target}' not found. Available columns: {list(df.columns)}\n"
            "Pass the correct column using --target COLUMN_NAME."
        )
    df = df.dropna(subset=[args.target]).drop_duplicates()
    if len(df) < 10:
        raise ValueError("Dataset must contain at least 10 labeled rows.")
    X = df.drop(columns=[args.target])
    y_raw = df[args.target].astype(str)
    if X.empty:
        raise ValueError("Dataset must have feature columns in addition to the target label.")

    encoder = LabelEncoder()
    y = encoder.fit_transform(y_raw)
    if len(encoder.classes_) < 2:
        raise ValueError("The label column must contain at least two classes, such as Normal and Attack.")

    numeric_cols = X.select_dtypes(include=["number", "bool"]).columns.tolist()
    categorical_cols = [c for c in X.columns if c not in numeric_cols]
    transformers = []
    if numeric_cols:
        transformers.append(("numeric", Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
        ]), numeric_cols))
    if categorical_cols:
        transformers.append(("categorical", Pipeline([
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore")),
        ]), categorical_cols))
    preprocessor = ColumnTransformer(transformers=transformers)

    model = Pipeline([
        ("preprocessor", preprocessor),
        ("classifier", RandomForestClassifier(
            n_estimators=150, random_state=42, class_weight="balanced"
        )),
    ])

    counts = pd.Series(y).value_counts()
    stratify = y if counts.min() >= 2 else None
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=stratify
    )
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    print("\n=== Evaluation ===")
    print(f"Rows: {len(df)} | Features: {X.shape[1]}")
    print(f"Accuracy: {accuracy_score(y_test, predictions):.4f}")
    print("\nClassification report:")
    print(classification_report(
        y_test, predictions,
        labels=list(range(len(encoder.classes_))),
        target_names=encoder.classes_,
        zero_division=0,
    ))
    print("Confusion matrix:")
    print(confusion_matrix(y_test, predictions))

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump({
        "model": model,
        "label_encoder": encoder,
        "feature_columns": list(X.columns),
        "target_column": args.target,
    }, MODEL_PATH)
    print(f"\nModel saved successfully: {MODEL_PATH}")
    print("Reminder: if using synthetic data, these metrics are only for demonstration.")

if __name__ == "__main__":
    main()
