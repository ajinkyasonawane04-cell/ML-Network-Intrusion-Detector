"""Generate a synthetic sample CSV so the project runs immediately.
This is simulated data for software testing, not a real public dataset.
"""
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "dataset" / "sample_network_traffic.csv"

def main():
    rng = np.random.default_rng(42)
    n_normal, n_attack = 700, 300
    n = n_normal + n_attack
    labels = np.array(["Normal"] * n_normal + ["Attack"] * n_attack)
    rng.shuffle(labels)
    attack = labels == "Attack"
    df = pd.DataFrame({
        "duration": np.round(np.where(attack, rng.exponential(1.2, n), rng.exponential(8.0, n)), 4),
        "src_bytes": np.round(np.where(attack, rng.lognormal(7.0, 1.1, n), rng.lognormal(8.0, 1.0, n))).astype(int),
        "dst_bytes": np.round(np.where(attack, rng.lognormal(4.8, 1.2, n), rng.lognormal(7.0, 1.0, n))).astype(int),
        "packet_count": np.where(attack, rng.poisson(90, n), rng.poisson(35, n)),
        "failed_logins": np.where(attack, rng.poisson(3.0, n), rng.poisson(0.15, n)),
        "protocol": rng.choice(["tcp", "udp", "icmp"], n, p=[0.72, 0.23, 0.05]),
        "service": rng.choice(["http", "https", "dns", "ssh", "other"], n),
        "flag": np.where(attack, rng.choice(["S0", "REJ", "SF"], n, p=[0.55, 0.3, 0.15]),
                         rng.choice(["SF", "S1", "S2"], n, p=[0.8, 0.1, 0.1])),
        "label": labels,
    })
    OUT.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(OUT, index=False)
    print(f"Created {len(df)} sample rows at: {OUT}")
    print("This is synthetic demo data, not a real public dataset.")
    print(df.head())

if __name__ == "__main__":
    main()
