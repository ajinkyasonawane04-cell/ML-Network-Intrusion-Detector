# Network Intrusion Detector — fixed starter project

## Fix for `FileNotFoundError: No CSV dataset found`

The training script expects a CSV inside `dataset/`. This package includes a generator that creates a labeled sample CSV.

## Windows PowerShell steps

Open this folder in VS Code, then run:

```powershell
python -m pip install -r requirements.txt
python generate_sample_data.py
python train_model.py
python predict.py dataset/sample_network_traffic.csv
```

If you want to use your existing virtual environment from the parent directory, use the exact Python executable:

```powershell
..\.venv\Scripts\python.exe -m pip install -r requirements.txt
..\.venv\Scripts\python.exe generate_sample_data.py
..\.venv\Scripts\python.exe train_model.py
..\.venv\Scripts\python.exe predict.py dataset/sample_network_traffic.csv
```

The second block assumes this project folder is nested inside the parent folder containing `.venv`.

## Dataset format

CSV must contain a target column named `label` by default, with at least two classes (e.g. `Normal`, `Attack`) and feature columns. If the target column has another name:

```powershell
python train_model.py --data dataset/mydata.csv --target class
```

## Limitations

The generated CSV is synthetic for testing code and is not a real public network dataset. It is not suitable for claiming real-world intrusion detection accuracy. For an academic evaluation, use a legitimate public dataset (for example CIC-IDS2017 or UNSW-NB15), confirm its label column and feature names, and evaluate precision, recall, F1 and false positives. This is an offline demo, not a live packet capture tool.
