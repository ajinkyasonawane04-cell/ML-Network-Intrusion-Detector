"""Predict labels for rows in a CSV file.
Usage:
    python predict.py dataset/sample_network_traffic.csv
"""
from pathlib import Path
import argparse
import joblib
import pandas as pd

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / "model" / "intrusion_model.pkl"

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("csv", help="CSV file to predict; may include label column")
    args = parser.parse_args()
    if not MODEL_PATH.exists():
        raise FileNotFoundError("Trained model missing. Run: python train_model.py")
    path = Path(args.csv)
    if not path.is_absolute():
        path = ROOT / path
    if not path.exists():
        raise FileNotFoundError(f"Prediction CSV not found: {path}")

    bundle = joblib.load(MODEL_PATH)
    df = pd.read_csv(path)
    features = bundle["feature_columns"]
    missing = [col for col in features if col not in df.columns]
    if missing:
        raise ValueError(f"Prediction CSV is missing feature columns: {missing}")
    X = df[features]
    pred_ids = bundle["model"].predict(X).astype(int)
    df["predicted_label"] = bundle["label_encoder"].inverse_transform(pred_ids)
    out = ROOT / "prediction_results.csv"
    df.to_csv(out, index=False)
    print(df[["predicted_label"]].head(10).to_string(index=False))
    print(f"\nSaved predictions to: {out}")

if __name__ == "__main__":
    main()
